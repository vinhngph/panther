import "./services/onUpdated.js";
import "./services/onInstalled.js";